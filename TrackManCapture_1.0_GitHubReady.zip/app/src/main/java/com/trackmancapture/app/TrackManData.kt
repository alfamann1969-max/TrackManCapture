package com.trackmancapture.app

import android.content.Context
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** One OCR row from one of TrackMan's two table views. */
data class ShotRow(
    val club: String? = null,
    val mode: String,
    val col1: Double? = null,
    val col2: Double? = null,
    val col3: Double? = null,
    val col4: Double? = null,
    val raw: String = "",
    val firstSeen: Long = System.nanoTime()
) {
    fun values() = listOf(col1, col2, col3, col4)
    fun signature(): String = buildString {
        append(mode).append('|')
        values().forEach { append(it?.let { v -> String.format(Locale.US, "%.2f", v) } ?: "_").append('|') }
    }

}

data class ParsedFrame(val mode: String, val club: String?, val rows: List<ShotRow>, val rawText: String)

data class MergedShot(
    val shot: Int,
    val club: String?,
    val startAngle: Double?,
    val startDirection: Double?,
    val carrySide: Double?,
    val targetDistance: Double?,
    val carry: Double?,
    val total: Double?,
    val ballSpeed: Double?,
    val height: Double?
)

object ShotStore {
    private const val FILE = "shots_v06.csv"
    private const val HEADER = "firstSeen;club;mode;col1;col2;col3;col4;raw\n"

    @Synchronized fun appendUnique(context: Context, rows: List<ShotRow>) {
        if (rows.isEmpty()) return
        val file = File(context.filesDir, FILE)
        if (!file.exists()) file.writeText(HEADER)

        // Signature is deliberately independent of screen Y so the same row is removed
        // when the user scrolls and it appears at a different position.
        val signatures = loadRows(context).map { it.signature() }.toHashSet()
        rows.sortedBy { it.firstSeen }.forEach { row ->
            if (signatures.add(row.signature())) {
                file.appendText(row.csvLine() + "\n")
            }
        }
    }

    private fun ShotRow.csvLine(): String = listOf(
        firstSeen.toString(), club.orEmpty(), mode,
        col1, col2, col3, col4, raw.replace(";", ",").replace("\n", " ")
    ).joinToString(";") { it?.toString() ?: "" }

    fun loadRows(context: Context): List<ShotRow> {
        val file = File(context.filesDir, FILE)
        if (!file.exists()) return emptyList()
        return file.readLines().drop(1).mapNotNull { line ->
            val p = line.split(';', limit = 8)
            if (p.size < 8) return@mapNotNull null
            ShotRow(
                club = p[1].ifBlank { null }, mode = p[2],
                col1 = p[3].toDoubleOrNull(), col2 = p[4].toDoubleOrNull(),
                col3 = p[5].toDoubleOrNull(), col4 = p[6].toDoubleOrNull(),
                raw = p[7], firstSeen = p[0].toLongOrNull() ?: Long.MAX_VALUE
            )
        }.sortedBy { it.firstSeen }
    }

    fun merge(context: Context): List<MergedShot> {
        val launch = loadRows(context).filter { it.mode == "launch_direction_carry_side_total" }.sortedBy { it.firstSeen }
        val speed = loadRows(context).filter { it.mode == "carry_total_speed_height" }.sortedBy { it.firstSeen }
        val n = maxOf(launch.size, speed.size)
        return (0 until n).map { i ->
            val a = launch.getOrNull(i)
            val b = speed.getOrNull(i)
            MergedShot(
                shot = i + 1,
                club = a?.club ?: b?.club,
                startAngle = a?.col1,
                startDirection = a?.col2,
                carrySide = a?.col3,
                targetDistance = a?.col4,
                carry = b?.col1,
                total = b?.col2,
                ballSpeed = b?.col3,
                height = b?.col4
            )
        }
    }

    fun count(context: Context): Int = loadRows(context).size

    fun modeCount(context: Context, mode: String): Int = loadRows(context).count { it.mode == mode }

    fun clear(context: Context) { File(context.filesDir, FILE).delete() }

    fun exportMergedCsv(context: Context): File {
        val out = File(context.cacheDir, "trackman-merged-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.GERMANY).format(Date())}.csv")
        val header = "Schlag;Schläger;Startwinkel;Startrichtung;Carry-Seite;Zielentfernung;Carry;Total;Ballgeschwindigkeit;Höhe\n"
        out.writeText(header)
        merge(context).forEach { s ->
            out.appendText(listOf(s.shot, s.club.orEmpty(), s.startAngle, s.startDirection, s.carrySide, s.targetDistance, s.carry, s.total, s.ballSpeed, s.height)
                .joinToString(";") { it?.toString() ?: "" } + "\n")
        }
        return out
    }

    fun exportRawCsv(context: Context): File {
        val out = File(context.cacheDir, "trackman-raw-${SimpleDateFormat("yyyyMMdd-HHmm", Locale.GERMANY).format(Date())}.csv")
        val source = File(context.filesDir, FILE)
        if (source.exists()) source.copyTo(out, true) else out.writeText(HEADER)
        return out
    }
}
