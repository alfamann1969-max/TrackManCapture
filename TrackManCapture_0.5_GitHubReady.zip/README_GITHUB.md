# TrackMan Capture 0.4 – GitHub APK Build

Dieses Projekt enthält einen GitHub-Actions-Workflow, der automatisch eine installierbare Debug-APK baut.

Workflow: `.github/workflows/build-apk.yml`

Der Workflow verwendet Java 17 und Gradle 8.11.1. Nach dem Build liegt die APK als GitHub Actions Artifact vor.
