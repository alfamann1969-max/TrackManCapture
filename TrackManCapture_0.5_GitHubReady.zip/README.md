# TrackMan Capture 0.4 – zwei Ansichten zusammenführen

Android-Prototyp zum Auslesen der sichtbaren TrackMan-Shot-Tabelle und Zusammenführen der beiden relevanten Datenansichten.

## Erfasste Ansichten

1. **Startwinkel / Startrichtung / Carry-Seite / Zielentfernung**
2. **Carry / Total / Ballgeschwindigkeit / Höhe**

Die App dedupliziert eine Zeile anhand ihrer Werte und nicht anhand ihrer Bildschirmposition. Dadurch kann dieselbe Zeile beim Scrollen an einer anderen Y-Position erneut erkannt werden, ohne doppelt gespeichert zu werden.

## Zusammenführung

Nachdem beide Ansichten vollständig erfasst wurden, werden die deduplizierten Zeilen innerhalb jeder Ansicht nach ihrer ersten Erfassung sortiert und anschließend über die Schlag-Reihenfolge gepaart. Der CSV-Export enthält:

`Schlag;Schläger;Startwinkel;Startrichtung;Carry-Seite;Zielentfernung;Carry;Total;Ballgeschwindigkeit;Höhe`

## Nutzung

1. Projekt in Android Studio öffnen.
2. Auf einem Android-Gerät installieren.
3. **Letztes TrackMan-Training auslesen** drücken und Bildschirmfreigabe erlauben.
4. TrackMan öffnen.
5. Die Shot-by-Shot-Liste auf **Ansicht 1** stellen und langsam bis zum Ende scrollen.
6. Auf **Ansicht 2** wechseln und ebenfalls bis zum Ende scrollen.
7. Auslesen stoppen.
8. **Zusammengeführte Schlagdaten teilen** wählen.

## Einschränkung

Die App greift nicht auf ein TrackMan-Konto und nicht auf eine nicht öffentliche API zu. Sie verarbeitet ausschließlich den vom Nutzer ausdrücklich freigegebenen Bildschirm. Die Zuordnung der beiden Tabellen erfolgt über ihre Schlag-Reihenfolge. Bei fehlenden OCR-Zeilen kann dadurch eine Verschiebung entstehen; deshalb ist die CSV zusätzlich mit Rohdaten exportierbar.

## Datenschutz

Die erkannten Daten werden lokal im App-Speicher abgelegt. Es gibt keinen eigenen Server und keinen automatischen Upload.
