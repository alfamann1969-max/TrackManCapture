package com.trackmancapture.app

import com.google.mlkit.vision.text.Text
import java.util.Locale

object TrackManParser {
    private val decimal = Regex("[-+]?\\d+(?:[.,]\\d+)?")
    private val clubRx = Regex("(?i)\\b(?:[3-9]\\s?[iI]|[2-5]\\s?[Hh]|PW|AW|GW|SW|LW|DR|DW)\\b")

    fun parse(result: Text): ParsedFrame {
        val allText = result.text
        val mode = detectMode(allText)
        val club = clubRx.find(allText)?.value?.replace(" ", "")
        val lines = result.textBlocks.flatMap { it.lines }
        val rows = lines.mapNotNull { line -> parseLine(line, mode, club) }
        return ParsedFrame(mode, club, rows, allText)
    }

    private fun detectMode(text: String): String {
        val t = text.lowercase(Locale.GERMANY)
        return when {
            ("ballgeschw" in t || "ballgesch" in t || "ball speed" in t || "höhe" in t || "height" in t) && "total" in t -> "carry_total_speed_height"
            ("startwinkel" in t || "launch angle" in t) && ("startrichtung" in t || "launch direction" in t) -> "launch_direction_carry_side_total"
            else -> "unknown"
        }
    }

    private fun parseLine(line: Text.Line, mode: String, club: String?): ShotRow? {
        if (mode == "unknown") return null
        val box = line.boundingBox ?: return null
        if (box.centerY() < 160) return null
        val elements = line.elements
        if (elements.isEmpty()) return null
        val right = elements.maxOfOrNull { it.boundingBox?.right ?: 0 } ?: return null
        if (right < 250) return null

        val nums = elements.mapNotNull { e ->
            val eb = e.boundingBox ?: return@mapNotNull null
            val text = e.text.replace('O', '0').replace('l', '1')
            val match = decimal.find(text) ?: return@mapNotNull null
            val value = match.value.replace(',', '.').toDoubleOrNull() ?: return@mapNotNull null
            Triple(eb.centerX().toFloat() / right, value, eb.centerX())
        }
        if (nums.size < 3) return null

        val cols = arrayOfNulls<Double>(4)
        nums.forEach { (x, value, _) ->
            val idx = when {
                x < 0.31f -> 0
                x < 0.54f -> 1
                x < 0.77f -> 2
                else -> 3
            }
            if (cols[idx] == null) cols[idx] = value
        }
        if (cols.count { it != null } < 3) return null

        val raw = line.text.replace("\n", " ").trim()
        // A row signature must not depend on Y: the same row moves when TrackMan scrolls.
        return ShotRow(club, mode, cols[0], cols[1], cols[2], cols[3], raw)
    }
}
