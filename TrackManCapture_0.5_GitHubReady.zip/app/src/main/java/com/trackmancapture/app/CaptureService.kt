package com.trackmancapture.app

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import androidx.core.app.NotificationCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

class CaptureService : Service() {
    companion object {
        const val EXTRA_RESULT_CODE = "resultCode"
        const val EXTRA_RESULT_DATA = "resultData"
        private const val CHANNEL = "capture"
        private const val NOTIFY = 77
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val handler = Handler(Looper.getMainLooper())
    private var busy = false
    private val recognizer by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }

    override fun onCreate() {
        super.onCreate()
        createChannel()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(NOTIFY, notification("Bereit – TrackMan öffnen"), ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else startForeground(NOTIFY, notification("Bereit – TrackMan öffnen"))
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        val code = intent?.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED) ?: return START_NOT_STICKY
        val data = intent.getParcelableExtraCompat<Intent>(EXTRA_RESULT_DATA) ?: return START_NOT_STICKY
        startCapture(code, data)
        return START_NOT_STICKY
    }

    private fun startCapture(code: Int, data: Intent) {
        if (projection != null) return
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(code, data)
        val metrics = resources.displayMetrics
        val w = metrics.widthPixels
        val h = metrics.heightPixels
        val dpi = metrics.densityDpi
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        projection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopCapture() }
        }, handler)
        display = projection?.createVirtualDisplay(
            "TrackManCapture", w, h, dpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, handler
        )

        reader?.setOnImageAvailableListener({ r ->
            if (busy) { r.acquireLatestImage()?.close(); return@setOnImageAvailableListener }
            val image = r.acquireLatestImage() ?: return@setOnImageAvailableListener
            busy = true
            try {
                val plane = image.planes[0]
                val strideWidth = plane.rowStride / plane.pixelStride
                val raw = Bitmap.createBitmap(strideWidth, image.height, Bitmap.Config.ARGB_8888)
                raw.copyPixelsFromBuffer(plane.buffer)
                image.close()
                val bitmap = if (strideWidth != w) Bitmap.createBitmap(raw, 0, 0, w, h) else raw
                if (bitmap !== raw) raw.recycle()
                process(bitmap)
            } catch (_: Throwable) {
                image.close()
                busy = false
            }
        }, handler)
        handler.postDelayed(object : Runnable {
            override fun run() {
                if (projection != null) {
                    reader?.acquireLatestImage()?.close()
                    handler.postDelayed(this, 1300)
                }
            }
        }, 1300)
    }

    private fun process(bitmap: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bitmap, 0))
            .addOnSuccessListener { result ->
                val parsed = TrackManParser.parse(result)
                if (parsed.rows.isNotEmpty()) ShotStore.appendUnique(this, parsed.rows)
                val mode = parsed.mode.replace('_', ' ')
                updateNotification("$mode · ${ShotStore.count(this)} Tabellenzeilen")
            }
            .addOnFailureListener { updateNotification("OCR-Fehler – bitte TrackMan-Liste anzeigen") }
            .addOnCompleteListener { busy = false; bitmap.recycle() }
    }

    private fun stopCapture() {
        display?.release(); display = null
        reader?.close(); reader = null
        projection?.stop(); projection = null
        stopSelf()
    }

    override fun onDestroy() { stopCapture(); recognizer.close(); super.onDestroy() }
    override fun onBind(intent: Intent?) = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            getSystemService(NotificationManager::class.java)
                .createNotificationChannel(NotificationChannel(CHANNEL, "TrackMan Capture", NotificationManager.IMPORTANCE_LOW))
        }
    }
    private fun notification(text: String) = NotificationCompat.Builder(this, CHANNEL)
        .setSmallIcon(android.R.drawable.ic_menu_camera)
        .setContentTitle("TrackMan Capture")
        .setContentText(text)
        .setOngoing(true).build()
    private fun updateNotification(text: String) = getSystemService(NotificationManager::class.java).notify(NOTIFY, notification(text))
}

@Suppress("DEPRECATION")
private inline fun <reified T> Intent.getParcelableExtraCompat(name: String): T? =
    if (Build.VERSION.SDK_INT >= 33) getParcelableExtra(name, T::class.java) else getParcelableExtra(name)
