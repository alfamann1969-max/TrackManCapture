package com.trackmancapture.app

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat

class MainActivity : AppCompatActivity() {
    private val projectionRequest = 4101
    private val notificationRequest = 4102
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        status = TextView(this).apply { textSize = 16f; setPadding(0, 0, 0, 24) }
        val start = Button(this).apply { text = "Letztes TrackMan-Training auslesen" }
        val open = Button(this).apply { text = "TrackMan öffnen" }
        val stop = Button(this).apply { text = "Auslesen stoppen" }
        val merged = Button(this).apply { text = "Zusammengeführte Schlagdaten teilen" }
        val raw = Button(this).apply { text = "Rohdaten teilen" }
        val clear = Button(this).apply { text = "Daten dieser Session löschen" }
        val help = TextView(this).apply {
            text = "Ablauf:\n1. Auslesen starten und Bildschirmfreigabe erlauben.\n2. TrackMan öffnen.\n3. Letztes Training und Shot-by-Shot-Tabelle anzeigen.\n4. Die erste Tabelle (Startwinkel/Startrichtung/Carry-Seite/Zielentfernung) komplett durchscrollen.\n5. Danach in TrackMan auf die zweite Tabelle (Carry/Total/Ballgeschwindigkeit/Höhe) wechseln und ebenfalls komplett durchscrollen.\n6. Danach werden beide Ansichten nach ihrer Schlag-Reihenfolge zusammengeführt."
            setPadding(0, 24, 0, 0)
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(32, 32, 32, 32) }
        root.addView(status); root.addView(start); root.addView(open); root.addView(stop); root.addView(merged); root.addView(raw); root.addView(clear); root.addView(help)
        setContentView(root)
        refreshStatus()

        start.setOnClickListener {
            if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.POST_NOTIFICATIONS), notificationRequest)
            }
            val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
            startActivityForResult(mgr.createScreenCaptureIntent(), projectionRequest)
        }
        open.setOnClickListener {
            val intent = findTrackManIntent()
            if (intent != null) startActivity(intent) else status.text = "TrackMan nicht automatisch gefunden. Öffne die TrackMan-App manuell."
        }
        stop.setOnClickListener { stopService(Intent(this, CaptureService::class.java)); status.text = "Auslesen gestoppt." }
        merged.setOnClickListener { shareFile(ShotStore.exportMergedCsv(this), "text/csv", "Zusammengeführte TrackMan-Daten teilen") }
        raw.setOnClickListener { shareFile(ShotStore.exportRawCsv(this), "text/csv", "TrackMan-Rohdaten teilen") }
        clear.setOnClickListener { ShotStore.clear(this); refreshStatus() }
    }

    private fun findTrackManIntent(): Intent? {
        val candidates = listOf("com.trackman.golf", "com.trackman.golf.app", "dk.Trackman.Range", "dk.trackman.range")
        return candidates.firstNotNullOfOrNull { packageManager.getLaunchIntentForPackage(it) }
    }

    override fun onResume() { super.onResume(); refreshStatus() }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == projectionRequest && resultCode == Activity.RESULT_OK && data != null) {
            val intent = Intent(this, CaptureService::class.java).apply {
                putExtra(CaptureService.EXTRA_RESULT_CODE, resultCode)
                putExtra(CaptureService.EXTRA_RESULT_DATA, data)
            }
            ContextCompat.startForegroundService(this, intent)
            status.text = "Auslesen läuft. TrackMan öffnen und beide Shot-Tabellen nacheinander komplett anzeigen."
        } else if (requestCode == projectionRequest) status.text = "Bildschirmfreigabe wurde nicht freigegeben."
    }

    private fun refreshStatus() {
        val all = ShotStore.count(this)
        val a = ShotStore.modeCount(this, "launch_direction_carry_side_total")
        val b = ShotStore.modeCount(this, "carry_total_speed_height")
        val merged = ShotStore.merge(this).size
        status.text = "TrackMan Capture 0.4\n\nErkannte Zeilen: $all\nAnsicht 1: $a\nAnsicht 2: $b\nZusammengeführte Schläge: $merged\n\nDie Zuordnung erfolgt anhand der Reihenfolge der deduplizierten Schläge."
    }

    private fun shareFile(file: java.io.File, mime: String, title: String) {
        val uri = androidx.core.content.FileProvider.getUriForFile(this, "com.trackmancapture.app.fileprovider", file)
        val send = Intent(Intent.ACTION_SEND).apply { type = mime; putExtra(Intent.EXTRA_STREAM, uri); addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION) }
        startActivity(Intent.createChooser(send, title))
    }
}
