# TrackMan Capture – APK bauen (kostenlos)

## Variante A: GitHub Actions (empfohlen)

1. Auf https://github.com ein kostenloses Konto anlegen oder anmelden.
2. Ein neues Repository anlegen, z. B. `TrackManCapture`.
3. Die **Inhalte dieses Ordners** in das Repository hochladen (nicht den ZIP-Container selbst).
4. Auf **Actions** gehen.
5. Den Workflow **Build TrackMan Capture APK** auswählen.
6. **Run workflow** drücken.
7. Nach erfolgreichem Build den Bereich **Artifacts** öffnen und `TrackMan-Capture-debug-APK` herunterladen.
8. Die darin enthaltene `app-debug.apk` auf das Samsung kopieren und installieren.

Der Workflow baut automatisch bei einem Push auf `main` und kann zusätzlich manuell gestartet werden.

## Variante B: lokal mit Android Studio

Projekt in Android Studio öffnen und `Build > Build APK(s)` wählen.

## Hinweis

Die APK ist eine Debug-Version und für persönliche Tests gedacht. Für eine Veröffentlichung im Play Store braucht die App eine eigene Release-Signatur.
